`gg` will be moved to its own repository:

https://github.com/vlang/gg
