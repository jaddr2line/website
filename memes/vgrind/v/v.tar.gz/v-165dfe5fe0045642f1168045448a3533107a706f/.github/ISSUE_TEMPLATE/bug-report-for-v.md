---
name: Bug report for V
about: Please use the apropriate label when submitting an issue: bug/feature request/question.
title: "New issue"
labels: ''
assignees: ''

---

#### V version:


#### OS:


#### C Compiler:


## What did you do?


### What did you expect to see?


### What did you see instead?
