---
name: Bug report
about: Bug report
title: ''
labels: bug
assignees: ''

---

**V version:** 
**OS:** 

**What did you do?**


**What did you expect to see?**

 
**What did you see instead?**
