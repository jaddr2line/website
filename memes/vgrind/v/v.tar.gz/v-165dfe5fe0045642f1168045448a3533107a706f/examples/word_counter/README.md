```
usage: word_counter [text_file]
using cinderella.txt
able => 2
afterwards => 1
after => 1
against => 2
again => 10
allowed => 2
allow => 1
all => 12
along => 1
also => 2
always => 2
and => 140
anew => 1
anger => 1
another => 2
answered => 1
anyone => 2
any => 1
an => 4
...
```
