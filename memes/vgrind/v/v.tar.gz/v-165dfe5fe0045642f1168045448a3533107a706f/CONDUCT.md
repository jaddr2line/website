Be nice and respectful.
